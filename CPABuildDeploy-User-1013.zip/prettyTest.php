<?php
echo (isset($_GET['pretty']) && $_GET['pretty']==1) ? 1 : 0;